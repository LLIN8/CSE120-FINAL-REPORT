package com.example.liangminglin.testing;

/**
 * Created by liangminglin on 11/30/17.
 */

public class Test {


    private String NAME;
    private String NUM;
    private String VALUE;

    public void setNAME(String NAME) {
        this.NAME = NAME;
    }

    public void setNUM(String NUM) {
        this.NUM = NUM;
    }

    public void setVALUE(String VALUE) {
        this.VALUE = VALUE;
    }

    public String getNAME() {
        return NAME;
    }

    public String getNUM() {
        return NUM;
    }

    public String getVALUE() {
        return VALUE;
    }

}
